# PROGETTO COMPLESSIVO REAME_MSYS_PROJECT.MD

SI TROVA IN QUESTA DIRECTORY:
c:\CASA\LINGUAGGI\ACCESS\PROGETTI_MDB\MSYS\

## NOTE
il progetto complessivo per la gestione degli oggetti Msys

## FINALITA

SVILUPPO MODULARE E SEPARATO E DEFINIZIONI
  
  Il progetto MSys ha la finalita di creare un PROGETTO MASTER che possa controllare
  l'utilizzo degli oggetti in access sia nel progetto Master e sia nei sottoprogetti.
  Essendo molto coplicato riunire le tabelle, le form le quesy e gli altri oggetti, ecc..
  in un uni progetto in cui si ha il rischio di blocco del database e quindi di perdere tutto 
  ho deciso di frazionare ogni attivita in sotto directory separate. 
  Ogni sottodirectory rappresenta una tabella specifica, che appartiene :
    1) gruppo DFXX = tabelle di definizioni o 
    2) gruppo TBXX = tabelle di archivio dati anche temporanei es: TBXX_TMP.
  
  In questo esempio descrivo una tabella di definzione partendo da:
    CARTELLA MSys_DF01
      contiene la tabella di definizione DEI COMANDI DEL MENU di servizio all'intero progetto
      e quindi le query le form e gli altri oggetti di servizio ai menu.
      Quindi ho creato un database chiamato 
        MSys_DF01.mdb
      che contiene la tabella
        MSys_DF01_COMANDI       = cioè la tabella di definizione dei comandi
      la query
        MSys_DF01_COMANDI_Qry01_01_SELECT_TUTTI
      che estrae i dati dalla df01.
      Quindi la logica è che ogni database è separato dagli altri, ha una funzione 
      specifica e viene denominato con la caratteristica di riferimento 
        DEFINZIONI oppure TABELLE, DF o TB.
      Tutti gli oggetti hanno denominazione con questa caratteristica es:
        MSys                    = il progetto oggetti access dalle tabella di sistema Msys ...
        MSys_DF01               = il progetto oggetti ha un mini progetto definzioni con questa
                                tabella MSys_DF01_COMANDI
        MSys_DF01_Qry01_SELECT  = il progetto oggetti ha QUESTA QUERY di tipo select che estrae
                                i comandi, infatti il nome definitivo è :
                                    MSys_DF01_COMANDI_Qry01_01_SELECT_TUTTI
PROBLEMA DI TROVARE DEFINIZIONI COMPATTE
  Con questo sistema ho il problema di definire Query, form report e moduli in modo compatto
  per evitare di consumare tutto lo spazionio per i nomi, infatti ad esempio se definsco
  la query select 
        MSys_DF01_COMANDI_Qry01_01_SELECT_TUTTI
  devo utilizzare le caratteristiche distintive di questo progetto perche gli oggetti
  potrebbero essere importati in altri progetti e quindi:
        Msys    = progetto
        DF01    = una tabella di definizioni
        Qry     = oggetto query 01 da numerare
        Select  = è una select non un delete 
  queste caratteristiche servono per fare dei filtri efficaci all'interno dei progetti
  molto strutturati e quindi fare una buona manutenzione.
  Esempio DF01 sarebbe il codice di estrazione di tutte le query del mini progetto 
  definizioni come Msys è la chiave di estrazione di tutti gli oggetti del progetto
  per cui estrae le query del gruppo es.
      MSys_DF01
      MSys_DF02 ec...
  Se volessi invece volessi estrare solo le query che appartengono a DF01 ma che siano
  select dovrei impostare il nome cosi:
       MSys_DF01_SELECT_..... ecc.
AIUTO A DEFINIRE LE CHIAVI DI ESTRAZIONE
  quindi chiedo una aiuto affinche posso definire bene l'albero delle cartele,
  il nome del db access, il codice di estrazione base per la tabella e gli oggetti
  ed il codice di estrazione dei singoli oggetti che appartengono a quel db,
  ossia partendo dalla tabella creare nomi significativi per la query, report, form
  moduli e classi.


L'albero delle cartelle è il seguente non è completo ma è un inizio.


## CARTELLE
codice ----> $Project$Msys.00_(LE CARTELLE DI TUTTO IL PROGETTO)

  MSYS/
      │
      │  --------------------------------------------------------------------------------------------------------------------------
      │           PROJECT                          CODICE_PROJECT                    ATTIVITA
      │  --------------------------------------------------------------------------------------------------------------------------
      │            │___MSYS_BASE/                            │  CODICE =BASE              │    = @DB@BASE da utilzzare per tutti i mini progetti 
      │            │___MSys_DF00/                            │  CODICE =DF00              │    = MODELLO BASE PER I PROGETTI MSYS                         - $Msys$DF00_(DF00 la base di tutto i progetti msys) 
      │            │___MSys_DF01/                            │  CODICE =DF01              │    = DEFINIZIONE DEI COMANDI DEL MENU                         - @comandi@menu_(di tutto il @superprogetto) 
      │            │___MSys_DF02/                            │  CODICE =DF02              │    = DEFINIZIONE DEI TIPI DI OGGETTO                          - @TIPO@DI@OGGETTO_(vengono definiti i tipi di oggetto gesti, FORM, QUERY TABELLE ECC..) 
      │            │___MSys_DF05/                            │  CODICE =DF05              │    = DEFINIZIONE DEGLI ATTRIBUTI DELLA TABELLA                - $MSys$DF05.00_(DF05 progetto sugli ATTRIBUTI DELLA TABELLA)
      │            │___MSys_DF10/                            │  CODICE =DF10              │    = DEFINIZIONE DEI DATABASE UTILIZZATI                      - @DATABASE@UTILIZZATI_(i vari database utilizzati per la gestione del progetto di importazone ed esportazione) todo: COME UTILIZZARLI? 
      │            │___MSys_DF11/                            │  CODICE =DF11              │    = DEFINIZIONE DEI CODICI DI PROGETTO                       - @CODICI@PROGETTO_(con la TABELLA @DF11 ad ogni sub progetto viene attribuito un @codice@progetto, anche al MASTER) 
      │            │___MSys_DF12/                            │  CODICE =DF12              │    = DEFINIZIONE DEGLI OGGETTI NECESSARI AL PROGETTO          - 8 oggetti necessari per oggi progetto @oggetti@object_(per ogni progetto occorrono 8 oggetti, QURY, FORM REPORT ECC.) TODO: come utilizzarli? 
      │            │___MSys_DF13/                            │  CODICE =DF13              │    = DEFINIZIONI DELL LIBRERIE DLL DEL PROGETTO               - @DLL_(per ogni progetto occorrono le librerie DLL da stabilire) 
      │            │___MSys_DF14/                            │  CODICE =DF14              │    = PATH DI SALVATAGGIO DELLE LIBRERIE ACCESS                - dove sono state salve @librerie_(dove si trovano o dove sono state salvate) 
      │            │___MSys_ELENCO/                          │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_ESPORTA/                         │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_FORMS/                           │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_FORMS_MASTER/                    │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_GE_FILE/         **              │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_MACRO/                           │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSYS_MENU/                            │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_MODULI/                          │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSYS_OBJECT_DB_EST/                   │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSYS_OGGETTI_OLD/                     │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_PAGINE/                          │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_QUERY/                           │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_REPORT/                          │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_TABELLE/                         │  CODICE =123456            │    = da definire l'utilizzo??
      │            │___MSys_TB01_PROGETTI/                   │  CODICE=                   │    = I CODICE DI PROGETTO E LA LORO DEFINIZIONE @CODICI@PROGETTI_(dove sono definiti i codice dei progetti la denominazione e cosa fanno)
      │            │___MSys_TB02_TIPO_OGGETTI/               │  CODICE=                   │    = IL GRUPPO DI OGGETTI NECESSARI AL FUNZIONAMENTO DEI PROGETTI @gruppo@oggetti_(raggruppamento degli oggetti per ogni progetto)
      │            │___MSys_TB03_ELENCO_OGGETTI/             │  CODICE=                   │    = ELENCO DEGLI OGGETTI ASSEGNATI ad ogni progetto @eleco@project_(tutti gli oggetti necessari)
      │            │___Msys_TB05_FORMS/                      │  CODICE=                   │    = MSYS PER LA GESTIONE DI TUTTE LE FORMS *** IN RICOSTRUZIONE   
      │            │___Msys_TB12_FILES/                      │  CODICE= TB12_FILES        │    = MSYS PER LA GESTIONE DEI FILE                           - @GESTIONE@FILE_(la gestione dei file e delle carelle con le classi syste e le @api@windows) 
      │            │___Msys_TB30_UTIL/                       │  CODICE= TB30_UTIL *       │    = UTILITA IMPORTA PROGETTI ED I SERVIZI *** IN RICOSTRUZIONE
      │            │___Msys_TB40_PROG_MASTER/                │                            │    = LE FORM MASTER E LE SOTTOFORM MASTER
      │            │___MSys_TB41_VISUAL_PAG_MASTER/          │                            │    = LA VISUALIZZAZIONE DELLE PAGINE
      │            │___MSys_TUTTI_MODELLI/                   │                            │    = da studiare come ridefinire queti mini progetti
      │            │___TAB_CONTROL/                          │                            │    = da studiare come ridefinire queti mini progetti
      │            │___TAB_CONTROL_MASTER_(401_402_501_502)/ │                            │    = da studiare come ridefinire queti mini progetti
      │            │___TMP_IMPORTA_MODULI/                   │                            │    = da studiare come ridefinire queti mini progetti
      │            │___TMP_IMPORTA_MODULIOBJECT/             │                            │    = da studiare come ridefinire queti mini progetti
      │            │___TMP_OGGETTI_DA_CANCELLARE/            │                            │    = da studiare come ridefinire queti mini progetti
      │            │___TREVIEW/                              │                            │    = da studiare come ridefinire queti mini progetti
      │            │___UTIL/                                 │                            │    = da studiare come ridefinire queti mini progetti
      │           
      ├─OBJECT/            
      ├─XLS/            
      ├─.gitignore            
      ├─AA________________________________________________________________________AA.txt
      ├─ATTIVA_SALVATAGGI_COLLETTIVI_MSYS_OGGETTI+MENU+IMPEGNI.BAT
      ├─CANCELLA_{MDB+OBJECT+PROJECT}.BAT
      ├─git_OPEN_OVERLEAF.BAT
      ├─git_OpenGitHub.bat
      ├─git_PULL.BAT
      ├─git_STATUS.BAT
      ├─git_STATUS+PULL+ADD+COMMIT+PUSH.BAT
      ├─MSYS_N02________________________________________________________________MSYS.txt
      ├─Project_MSYS.sublime-project
      ├─Project_MSYS.sublime-workspace
      ├─README.md
      ├─ZIP_7ZIP_________________________________________________________________ZZ.txt
      ├─ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}_CASA_C.BAT
      ├─ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}_SAN_GIORGIO_C.BAT
      ├─ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}_UFFICIO_C.BAT
      ├─Zip_N70_CRIPTA.bat
      ├─Zip_N70_DECODIFICA.bat
      ├─Zip_N70_ElencoFile.txt
      ├─Zip_N70_ElencoFileESCLUSI.txt
      └─ZZ________________________________________________________________________ZZ.txt

## OBIETTIVO FINALE
l'obiettivo finale del progetto Msys è quello di creare una FORM MASTER che permetta
il caricamento automatico dell form da scegliere in tabelle che rappresentano 
dei progetti. Mi sono creato una cartella ed denominata MSYS_ATTIVA_GEST_OGGETTI.mdb
per una form omonima ed ha la funzione di caricare diverse form a seconda del progetto
definito. Ovviamento le sottoform, le query i report e tutti gli oggetti necessari devono 
essere importati dagli altri progetti per funzionare e per ora mi limita a creare
un meccanismo di funzionamento collaudato.

## DEFINIZIONE STRUTTURALE
con questo obiettivo devo miglioare :
A) LA STRUTTURA DELLE CARTELLE
B) LA DEFINIZIONE DELLE CARTELLE
C) LA DEFINIZIONE DEI DATABASE ACESS
D) LA DEFINIZONE DELLE TABELLE DI GRUPPO TIPO DFXX O TBXX
E) LA DEFINIZIONE DELLE QUERY DEL MINI PROGETTO
F) LA DEFINZIONI DEGLI ALTRI OGGETTI, REPORT, FORM, MODULI CLASSI ECC..

il tutto per avere chiavi di estrazione da utilizzare nei proggetti che estraggono
in modo generale es:  Msys = tutti gli oggetti del progetto Msys ec...
le tabelle            MsysTb01 = tabella archivio ecc..
oggetti collegati     MsysQry01_SELECT_xx_attivita ECC...
                      MsysQry01_INSERT_xx_attivita ECC...
                      MsysQry01_UPDATE_xx_attivita ECC...
                      MsysFrm_MASTER_attivita ECC...
                      MsysFrm_Sottoform_attivita ECC...

tutto il progetto che sto riscrivento si trova qui:
c:\CASA\LINGUAGGI\ACCESS\PROGETTI_MDB\MSYS\


