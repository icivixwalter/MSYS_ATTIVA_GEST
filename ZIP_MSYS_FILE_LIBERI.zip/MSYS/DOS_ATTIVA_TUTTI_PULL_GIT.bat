@echo off
setlocal EnableExtensions
REM ==========================================================================
REM  NOME FILE : DOS_ATTIVA_TUTTI_PULL_GIT.bat
REM  POSIZIONE : c:\CASA\LINGUAGGI\ACCESS\PROGETTI_MDB\MSYS\
REM  SCOPO     : AGGIORNAMENTO COLLETTIVO da GitHub di tutti i micro progetti
REM              MSYS senza entrare in ogni cartella: esegue  git pull  in
REM              ogni sottocartella elencata nel SETTORE 3.
REM  LOG       : stesso nome del bat + _LOG.txt (accanto al bat)
REM              DOS_ATTIVA_TUTTI_PULL_GIT_LOG.txt
REM              aggiunto in coda ad ogni esecuzione.
REM ==========================================================================
REM
REM  STRUTTURA
REM  --------------------------------------------------------------------------
REM  SETTORE 1 - INIZIALIZZAZIONE
REM     1.1  posizionamento nella cartella del bat
REM     1.2  nome del LOG e intestazione
REM     1.3  impostazioni (FERMA_SU_ERRORE, OPZIONI_PULL, CONTROLLO_REMOTE)
REM  SETTORE 2 - CONTROLLI PRELIMINARI
REM     2.1  git installato e raggiungibile
REM  SETTORE 3 - ELENCO DELLE CARTELLE DA AGGIORNARE (un PARAGRAFO per cartella)
REM     3.01 ... 3.nn
REM  SETTORE 4 - RIEPILOGO FINALE
REM     4.1  conteggio OK / ERRORI / SALTATI
REM     4.2  elenco di tutte le cartelle, una riga per paragrafo
REM     4.3  esito finale e apertura del LOG se ci sono errori
REM
REM  COME AGGIUNGERE UNA CARTELLA
REM  --------------------------------------------------------------------------
REM  Nel SETTORE 3 copiare una riga e cambiare numero e cartella:
REM      call :PULL "3.20" "NUOVA_CARTELLA"
REM  - la cartella e' RELATIVA alla cartella di questo bat
REM    (si puo' anche scrivere un percorso completo c:\...\cartella)
REM  - per ESCLUDERE temporaneamente una cartella: mettere REM davanti alla riga
REM
REM  COME FUNZIONA OGNI PARAGRAFO  (routine :PULL in fondo al file)
REM  --------------------------------------------------------------------------
REM  - scrive nel LOG e a video: numero paragrafo, cartella, ora di inizio
REM  - controlla che la cartella esista e contenga un repository git (.git)
REM  - se CONTROLLO_REMOTE=1 controlla che il remote "origin" punti al
REM    repository con lo STESSO NOME della cartella (es. MSys_DF01 ->
REM    .../MSys_DF01.git): evita di scaricare il progetto sbagliato in una
REM    cartella copiata da un'altra con il remote non aggiornato
REM  - esegue  git pull %OPZIONI_PULL%  sul ramo corrente
REM    e copia nel LOG tutto l'output di git
REM  - legge il codice di uscita di git:
REM       0   = ESITO OK
REM       <>0 = ESITO ERRORE (conflitto, modifiche locali, rete, ...)
REM  - se FERMA_SU_ERRORE=1 dopo il primo errore i paragrafi successivi
REM    vengono SALTATI; con FERMA_SU_ERRORE=0 si prosegue con le altre
REM    cartelle (consigliato: un errore in un progetto non blocca gli altri)
REM ==========================================================================


REM ==========================================================================
REM  SETTORE 1 - INIZIALIZZAZIONE
REM ==========================================================================

REM --- 1.1 posizionamento nella cartella del bat -----------------------------
cd /d "%~dp0"
set "BASE=%~dp0"

REM --- 1.2 nome del LOG e intestazione ---------------------------------------
set "LOG=%~dpn0_LOG.txt"
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"`) do set "ADESSO=%%D"
if not defined ADESSO set "ADESSO=%date% %time%"

REM --- 1.3 impostazioni ------------------------------------------------------
REM     FERMA_SU_ERRORE = 0  -> in caso di errore prosegue con le altre cartelle
REM     FERMA_SU_ERRORE = 1  -> al primo errore salta tutti i paragrafi seguenti
set "FERMA_SU_ERRORE=0"
REM     OPZIONI_PULL = --ff-only -> aggiorna solo se non serve un merge:
REM                    se locale e remoto sono divergenti segnala ERRORE e
REM                    non tocca nulla (nessun merge automatico, nessun conflitto)
REM     OPZIONI_PULL =  (vuoto)  -> git pull normale (puo' creare merge)
set "OPZIONI_PULL=--ff-only"
REM     CONTROLLO_REMOTE = 1 -> il remote origin deve finire con <cartella>.git
REM     CONTROLLO_REMOTE = 0 -> nessun controllo sul nome del remote
set "CONTROLLO_REMOTE=1"
REM     CLONA_SE_MANCA = 1 -> se la cartella non esiste (o e' vuota) la scarica
REM                           da GitHub con git clone  GITHUB_BASE + cartella.git
REM                           (ricostruzione completa su un PC nuovo)
set "CLONA_SE_MANCA=1"
set "GITHUB_BASE=https://github.com/icivixwalter/"

set /a N_OK=0
set /a N_ERR=0
set /a N_SALT=0
set "STOP=0"
set "ELENCO_ERR="

REM  file temporanei: elenco riassuntivo del SETTORE 4.2 e output di git
set "RIEP=%TEMP%\DOS_ATTIVA_PULL_RIEPILOGO.tmp"
set "OUTGIT=%TEMP%\DOS_ATTIVA_PULL_OUTPUT.tmp"
if exist "%RIEP%" del "%RIEP%" >nul 2>&1

call :SCRIVI ""
call :SCRIVI "##########################################################################"
call :SCRIVI "  AGGIORNAMENTO COLLETTIVO MSYS (git pull) - avvio %ADESSO%"
call :SCRIVI "  cartella base    : %BASE%"
call :SCRIVI "  FERMA_SU_ERRORE  = %FERMA_SU_ERRORE%"
call :SCRIVI "  OPZIONI_PULL     = %OPZIONI_PULL%"
call :SCRIVI "  CONTROLLO_REMOTE = %CONTROLLO_REMOTE%"
call :SCRIVI "  CLONA_SE_MANCA   = %CLONA_SE_MANCA%  (%GITHUB_BASE%)"
call :SCRIVI "##########################################################################"
call :SCRIVI "SETTORE 1 - INIZIALIZZAZIONE ............................. OK"


REM ==========================================================================
REM  SETTORE 2 - CONTROLLI PRELIMINARI
REM ==========================================================================
call :SCRIVI "SETTORE 2 - CONTROLLI PRELIMINARI"

REM --- 2.1 git installato ----------------------------------------------------
where git >nul 2>&1
if errorlevel 1 (
    call :SCRIVI "  2.1 git installato ...................................... ERRORE"
    call :SCRIVI "      git non trovato nel PATH: impossibile proseguire."
    set "STOP=1"
    set "ELENCO_ERR= 2.1"
    set /a N_ERR+=1
    goto :SETTORE4
)
for /f "delims=" %%V in ('git --version') do set "GITVER=%%V"
call :SCRIVI "  2.1 git installato ...................................... OK (%GITVER%)"


REM ==========================================================================
REM  SETTORE 3 - ELENCO DELLE CARTELLE DA AGGIORNARE
REM  (per aggiungere: copiare una riga, cambiare numero e cartella)
REM  sono path relative
REM ==========================================================================
call :SCRIVI "SETTORE 3 - GIT PULL PER OGNI CARTELLA"

call :PULL "3.01" "MSYS_ATTIVA_GEST"
call :PULL "3.02" "MSys_DF00"
call :PULL "3.03" "MSys_DF01"
call :PULL "3.04" "MSys_DF02"
call :PULL "3.05" "MSys_DF03"
call :PULL "3.06" "MSys_DF04"
call :PULL "3.07" "MSys_DF05"
call :PULL "3.08" "MSys_DF06"
call :PULL "3.09" "MSys_DF10"
call :PULL "3.10" "MSys_DF11"
call :PULL "3.11" "MSys_DF12"
call :PULL "3.12" "MSys_DF13"
call :PULL "3.13" "MSys_DF14"
call :PULL "3.14" "MSys_TB01_PROGETTI"
call :PULL "3.15" "MSys_TB06_MENU"
call :PULL "3.16" "Msys_TB12_FILES"
call :PULL "3.17" "Msys_TB30_UTIL"
call :PULL "3.18" "MSys_TB99_LINK"
call :PULL "3.19" "MSys_TREEVIEW"
REM call :PULL "3.20" "NUOVA_CARTELLA"


REM ==========================================================================
REM  SETTORE 4 - RIEPILOGO FINALE
REM ==========================================================================
:SETTORE4
@echo off
cd /d "%BASE%"
if exist "%OUTGIT%" del "%OUTGIT%" >nul 2>&1
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"`) do set "FINE=%%D"
if not defined FINE set "FINE=%date% %time%"

call :SCRIVI ""
call :SCRIVI "SETTORE 4 - RIEPILOGO FINALE"
REM --- 4.1 conteggio ---------------------------------------------------------
call :SCRIVI "  4.1 cartelle OK      : %N_OK%"
call :SCRIVI "      cartelle ERRORE  : %N_ERR%"
call :SCRIVI "      cartelle SALTATE : %N_SALT%"
if defined ELENCO_ERR call :SCRIVI "      paragrafi in errore :%ELENCO_ERR%"
call :SCRIVI "  fine: %FINE%"

REM --- 4.2 elenco di tutte le cartelle ---------------------------------------
call :SCRIVI ""
call :SCRIVI "  4.2 ELENCO CARTELLE AGGIORNATE"
if not exist "%RIEP%" (
    call :SCRIVI "      nessuna cartella elaborata"
    goto :ESITO_FINALE
)
for /f "usebackq delims=" %%R in ("%RIEP%") do call :SCRIVI "      %%R"
del "%RIEP%" >nul 2>&1

REM --- 4.3 esito finale e apertura log ---------------------------------------
:ESITO_FINALE
call :SCRIVI ""
if "%N_ERR%"=="0" goto :TUTTO_OK
call :SCRIVI "  *** ESITO FINALE: CI SONO ERRORI - vedere il log ***"
call :SCRIVI "##########################################################################"
start "" notepad "%LOG%"
pause
endlocal
exit /b 1

:TUTTO_OK
call :SCRIVI "  ESITO FINALE: TUTTO OK"
call :SCRIVI "##########################################################################"
pause
endlocal
exit /b 0


REM ==========================================================================
REM  ROUTINE INTERNE
REM ==========================================================================

REM --------------------------------------------------------------------------
REM  :PULL "N.PARAGRAFO" "cartella"
REM --------------------------------------------------------------------------
:PULL
set "PAR=%~1"
set "REL=%~2"
REM  cartella relativa alla cartella base -> percorso assoluto
cd /d "%BASE%"
for %%F in ("%REL%") do set "DIR=%%~fF"
for %%G in ("%DIR%") do set "CARTELLA=%%~nxG"
set "INIZIO=%time%"
set "RAMO="
set "REMOTE="

call :SCRIVI ""
call :SCRIVI "  --------------------------------------------------------------------"
call :SCRIVI "  PARAGRAFO %PAR% - %REL%"
call :SCRIVI "      inizio: %INIZIO%"

if "%STOP%"=="1" (
    call :SCRIVI "      ESITO: SALTATO - blocco per errore precedente"
    >> "%RIEP%" echo(%PAR%  SALTATO  %CARTELLA%
    set /a N_SALT+=1
    exit /b 0
)

if exist "%DIR%\.git" goto :PULL_REPO_OK
REM  cartella mancante o vuota -> clone da GitHub (ricostruzione su PC nuovo)
set "VUOTA=1"
if exist "%DIR%\" for /f %%X in ('dir /b /a "%DIR%" 2^>nul') do set "VUOTA=0"
if "%CLONA_SE_MANCA%"=="1" if "%VUOTA%"=="1" goto :PULL_CLONA
call :SCRIVI "      ESITO: ERRORE - la cartella esiste ma non e' un repository git"
>> "%RIEP%" echo(%PAR%  ERRORE   %CARTELLA%   - non e' un repository git
goto :PULL_ERRORE

:PULL_CLONA
call :SCRIVI "      cartella mancante: clone da %GITHUB_BASE%%CARTELLA%.git"
git clone "%GITHUB_BASE%%CARTELLA%.git" "%DIR%" > "%OUTGIT%" 2>&1
set "RC=%errorlevel%"
type "%OUTGIT%"
>> "%LOG%" echo       --- output git clone ---
powershell -NoProfile -Command "Get-Content -LiteralPath '%OUTGIT%' | ForEach-Object { '      | ' + $_ }" >> "%LOG%"
>> "%LOG%" echo       --- fine output ---
if not "%RC%"=="0" (
    call :SCRIVI "      ESITO: ERRORE - git clone codice %RC%"
    >> "%RIEP%" echo(%PAR%  ERRORE   %CARTELLA%   - git clone codice %RC%
    goto :PULL_ERRORE
)
REM  regole locali: .gitignore e log restano solo sul PC (mai su GitHub)
(
    echo .gitignore
    echo git_LOG.txt
    echo AA_BACKUP_GITHUB/
    echo AA_SALVATAGGI/
) >> "%DIR%\.git\info\exclude"
call :SCRIVI "      fine  : %time%"
call :SCRIVI "      ESITO: OK - CLONATO"
>> "%RIEP%" echo(%PAR%  CLONATO  %CARTELLA%
set /a N_OK+=1
exit /b 0

:PULL_REPO_OK

for /f "delims=" %%B in ('git -C "%DIR%" branch --show-current 2^>nul') do set "RAMO=%%B"
for /f "delims=" %%U in ('git -C "%DIR%" remote get-url origin 2^>nul') do set "REMOTE=%%U"
call :SCRIVI "      ramo  : %RAMO%"
call :SCRIVI "      remote: %REMOTE%"

if not defined REMOTE (
    call :SCRIVI "      ESITO: ERRORE - remote origin non configurato"
    >> "%RIEP%" echo(%PAR%  ERRORE   %CARTELLA%   - remote origin mancante
    goto :PULL_ERRORE
)

REM  nome del repository remoto: ultima parte dell'url senza .git
set "RNOME="
for %%N in ("%REMOTE:/=\%") do set "RNOME=%%~nN"
if not "%CONTROLLO_REMOTE%"=="1" goto :PULL_ESEGUI
if /i "%RNOME%"=="%CARTELLA%" goto :PULL_ESEGUI
call :SCRIVI "      ESITO: ERRORE - il remote (%RNOME%) non corrisponde alla cartella %CARTELLA%"
call :SCRIVI "             correggere con: git remote set-url origin <url giusto>"
>> "%RIEP%" echo(%PAR%  ERRORE   %CARTELLA%   - remote %RNOME% non corrispondente
goto :PULL_ERRORE

:PULL_ESEGUI

git -C "%DIR%" pull %OPZIONI_PULL% > "%OUTGIT%" 2>&1
set "RC=%errorlevel%"
type "%OUTGIT%"
>> "%LOG%" echo       --- output git pull ---
powershell -NoProfile -Command "Get-Content -LiteralPath '%OUTGIT%' | ForEach-Object { '      | ' + $_ }" >> "%LOG%"
>> "%LOG%" echo       --- fine output ---

call :SCRIVI "      fine  : %time%"
if "%RC%"=="0" (
    call :SCRIVI "      ESITO: OK"
    >> "%RIEP%" echo(%PAR%  OK       %CARTELLA%
    set /a N_OK+=1
    exit /b 0
)

call :SCRIVI "      ESITO: ERRORE - git pull codice %RC%"
>> "%RIEP%" echo(%PAR%  ERRORE   %CARTELLA%   - git pull codice %RC%

:PULL_ERRORE
set /a N_ERR+=1
set "ELENCO_ERR=%ELENCO_ERR% %PAR%"
if "%FERMA_SU_ERRORE%"=="1" set "STOP=1"
exit /b 1

REM --------------------------------------------------------------------------
REM  :SCRIVI "testo"  -> scrive a video e nel log
REM --------------------------------------------------------------------------
:SCRIVI
if "%~1"=="" goto :SCRIVI_VUOTO
echo(%~1
>> "%LOG%" echo(%~1
exit /b 0
:SCRIVI_VUOTO
echo.
>> "%LOG%" echo.
exit /b 0
