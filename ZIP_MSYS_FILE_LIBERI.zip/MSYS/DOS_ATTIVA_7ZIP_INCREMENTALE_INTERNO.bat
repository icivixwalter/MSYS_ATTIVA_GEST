@echo off
setlocal EnableExtensions
REM ==========================================================================
REM  NOME FILE : DOS_ATTIVA_7ZIP_INCREMENTALE_INTERNO.bat
REM  POSIZIONE : c:\CASA\LINGUAGGI\ACCESS\PROGETTI_MDB\MSYS\
REM  SCOPO     : SALVATAGGIO 7-ZIP INCREMENTALE COLLETTIVO di tutti i micro
REM              progetti MSYS senza entrare in ogni cartella: attiva, uno
REM              dopo l'altro, i bat
REM                 ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT
REM              elencati nel SETTORE 3.
REM  LOG       : stesso nome del bat + _LOG.txt (accanto al bat)
REM              DOS_ATTIVA_7ZIP_INCREMENTALE_INTERNO_LOG.txt
REM              aggiunto in coda ad ogni esecuzione.
REM ==========================================================================
REM
REM  STRUTTURA
REM  --------------------------------------------------------------------------
REM  SETTORE 1 - INIZIALIZZAZIONE
REM     1.1  posizionamento nella cartella del bat
REM     1.2  nome del LOG e data/ora di avvio
REM     1.3  impostazioni (FERMA_SU_ERRORE, nome del log di debug)
REM  SETTORE 2 - CONTROLLI PRELIMINARI
REM     2.1  7-Zip installato (C:\Program Files\7-Zip\7z.exe)
REM  SETTORE 3 - ELENCO DEI BAT DA ATTIVARE  (un PARAGRAFO per cartella)
REM     3.01 ... 3.nn
REM  SETTORE 4 - RIEPILOGO FINALE
REM     4.1  conteggio OK / ERRORI / SALTATI
REM     4.2  elenco di tutti i bat attivati, una riga per paragrafo
REM     4.3  esito finale e apertura del LOG se ci sono errori
REM
REM  COME AGGIUNGERE UNA CARTELLA
REM  --------------------------------------------------------------------------
REM  Nel SETTORE 3 copiare una riga e cambiare numero e percorso:
REM      call :ATTIVA "3.19" "NUOVA_CARTELLA\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
REM  - il percorso e' RELATIVO alla cartella di questo bat
REM    (si puo' anche scrivere un percorso completo c:\...\file.bat)
REM  - il numero del paragrafo e' solo un'etichetta per il log:
REM    l'ordine di esecuzione e' quello delle righe
REM  - per ESCLUDERE temporaneamente una cartella: mettere REM davanti
REM
REM  COME FUNZIONA OGNI PARAGRAFO  (routine :ATTIVA in fondo al file)
REM  --------------------------------------------------------------------------
REM  - scrive nel LOG e a video: numero paragrafo, percorso, ora di inizio
REM  - controlla che il bat esista, altrimenti ERRORE
REM  - si posiziona nella cartella del bat (pushd) e lo attiva con CALL
REM    con l'input da NUL: i PAUSE / TIMEOUT dei bat figli (e dei loro
REM    Zip_N70_DECODIFICA.bat / Zip_N70_CRIPTA.bat) non bloccano il ciclo
REM  - legge il codice di uscita (ERRORLEVEL) del bat figlio:
REM       0   = ESITO OK   (7-Zip 0, oppure 1 = warning noto delle righe //)
REM       <>0 = ESITO ERRORE (cartella, data, lista file o 7-Zip >= 2)
REM  - LOG ALLINEATO AL FILE DI DEBUG della cartella
REM    (ZIP_7ZIP_INCREMENTALE_FILE_LOG.TXT, ricreato ad ogni esecuzione):
REM       OK     -> copia le righe chiave (archivio creato, esito 7-Zip,
REM                 esito CRIPTA)
REM       ERRORE -> copia le ultime 30 righe del file di debug
REM  - se FERMA_SU_ERRORE=1 dopo il primo errore i paragrafi successivi
REM    vengono SALTATI; con FERMA_SU_ERRORE=0 si prosegue
REM
REM  NOTA: ogni bat figlio ha il suo percorso scritto dentro (PATH_PART_S
REM        e FILE_S, righe "cambia questo parametro"): quando si copia il
REM        bat in una nuova cartella vanno cambiati, altrimenti salva la
REM        cartella sbagliata.
REM ==========================================================================


REM ==========================================================================
REM  SETTORE 1 - INIZIALIZZAZIONE
REM ==========================================================================

REM --- 1.1 posizionamento nella cartella del bat -----------------------------
cd /d "%~dp0"
set "BASE=%~dp0"

REM --- 1.2 nome del LOG e data/ora di avvio ----------------------------------
set "LOG=%~dpn0_LOG.txt"
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"`) do set "ADESSO=%%D"
if not defined ADESSO set "ADESSO=%date% %time%"

REM --- 1.3 impostazioni ------------------------------------------------------
REM     FERMA_SU_ERRORE = 0  -> in caso di errore prosegue con le altre cartelle
REM     FERMA_SU_ERRORE = 1  -> al primo errore salta tutti i paragrafi seguenti
set "FERMA_SU_ERRORE=0"
REM     nome del file di debug scritto da ogni bat figlio nella sua cartella
set "DEBUG_LOG=ZIP_7ZIP_INCREMENTALE_FILE_LOG.TXT"
REM     percorso di 7-Zip (lo stesso usato dai bat figli)
set "SETTEZIP=C:\Program Files\7-Zip\7z.exe"

set /a N_OK=0
set /a N_ERR=0
set /a N_SALT=0
set "STOP=0"
set "ELENCO_ERR="

REM  file temporaneo per l'elenco riassuntivo del SETTORE 4.2
set "RIEP=%TEMP%\DOS_ATTIVA_7ZIP_RIEPILOGO.tmp"
if exist "%RIEP%" del "%RIEP%" >nul 2>&1

call :SCRIVI ""
call :SCRIVI "##########################################################################"
call :SCRIVI "  SALVATAGGIO 7-ZIP INCREMENTALE COLLETTIVO MSYS - avvio %ADESSO%"
call :SCRIVI "  cartella base : %BASE%"
call :SCRIVI "  FERMA_SU_ERRORE = %FERMA_SU_ERRORE%"
call :SCRIVI "##########################################################################"
call :SCRIVI "SETTORE 1 - INIZIALIZZAZIONE ............................. OK"


REM ==========================================================================
REM  SETTORE 2 - CONTROLLI PRELIMINARI
REM ==========================================================================
call :SCRIVI "SETTORE 2 - CONTROLLI PRELIMINARI"

REM --- 2.1 7-Zip installato --------------------------------------------------
if not exist "%SETTEZIP%" (
    call :SCRIVI "  2.1 7-Zip installato .................................... ERRORE"
    call :SCRIVI "      non trovato: %SETTEZIP%"
    call :SCRIVI "      impossibile proseguire."
    set "STOP=1"
    set "ELENCO_ERR= 2.1"
    set /a N_ERR+=1
    goto :SETTORE4
)
call :SCRIVI "  2.1 7-Zip installato .................................... OK"


REM ==========================================================================
REM  SETTORE 3 - ELENCO DEI BAT DA ATTIVARE
REM  (per aggiungere: copiare una riga, cambiare numero e percorso)
REM  sono path relative alla cartella di questo bat
REM ==========================================================================
call :SCRIVI "SETTORE 3 - ATTIVAZIONE BAT 7-ZIP PER OGNI CARTELLA"

call :ATTIVA "3.01" "MSYS_ATTIVA_GEST\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.02" "MSys_DF00\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.03" "MSys_DF01\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.04" "MSys_DF02\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.05" "MSys_DF03\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.06" "MSys_DF04\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.07" "MSys_DF05\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.08" "MSys_DF06\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.09" "MSys_DF10\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.10" "MSys_DF11\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.11" "MSys_DF12\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.12" "MSys_DF13\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.13" "MSys_DF14\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.14" "MSys_TB01_PROGETTI\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.15" "MSys_TB06_MENU\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.16" "Msys_TB12_FILES\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.17" "Msys_TB30_UTIL\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
call :ATTIVA "3.18" "MSys_TB99_LINK\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"
REM call :ATTIVA "3.19" "NUOVA_CARTELLA\ZIP_7ZIP_INCREMENTALE_{CRIPTA+DECODIFICA_INTERNO}.BAT"


REM ==========================================================================
REM  SETTORE 4 - RIEPILOGO FINALE
REM ==========================================================================
:SETTORE4
@echo off
cd /d "%BASE%"
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"`) do set "FINE=%%D"
if not defined FINE set "FINE=%date% %time%"

call :SCRIVI ""
call :SCRIVI "SETTORE 4 - RIEPILOGO FINALE"
REM --- 4.1 conteggio ---------------------------------------------------------
call :SCRIVI "  4.1 cartelle OK      : %N_OK%"
call :SCRIVI "      cartelle ERRORE  : %N_ERR%"
call :SCRIVI "      cartelle SALTATE : %N_SALT%"
if defined ELENCO_ERR call :SCRIVI "      paragrafi in errore :%ELENCO_ERR%"
call :SCRIVI "  fine: %FINE%"

REM --- 4.2 elenco di tutti i bat attivati ------------------------------------
call :SCRIVI ""
call :SCRIVI "  4.2 ELENCO BAT ATTIVATI"
if not exist "%RIEP%" (
    call :SCRIVI "      nessun bat attivato"
    goto :ESITO_FINALE
)
for /f "usebackq delims=" %%R in ("%RIEP%") do call :SCRIVI "      %%R"
del "%RIEP%" >nul 2>&1

REM --- 4.3 esito finale e apertura log ---------------------------------------
:ESITO_FINALE
call :SCRIVI ""
if "%N_ERR%"=="0" goto :TUTTO_OK
call :SCRIVI "  *** ESITO FINALE: CI SONO ERRORI - vedere il log ***"
call :SCRIVI "##########################################################################"
start "" notepad "%LOG%"
pause
endlocal
exit /b 1

:TUTTO_OK
call :SCRIVI "  ESITO FINALE: TUTTO OK"
call :SCRIVI "##########################################################################"
pause
endlocal
exit /b 0


REM ==========================================================================
REM  ROUTINE INTERNE
REM ==========================================================================

REM --------------------------------------------------------------------------
REM  :ATTIVA "N.PARAGRAFO" "percorso\file.bat"
REM --------------------------------------------------------------------------
:ATTIVA
set "PAR=%~1"
set "REL=%~2"
REM  percorso relativo alla cartella base -> percorso assoluto
cd /d "%BASE%"
for %%F in ("%REL%") do set "FULL=%%~fF"
for %%F in ("%FULL%") do set "DIR=%%~dpF"
REM  nome della sola cartella (es. MSys_DF01) per l'elenco del SETTORE 4.2
for %%G in ("%DIR%.") do set "CARTELLA=%%~nxG"
set "DBG=%DIR%%DEBUG_LOG%"
set "INIZIO=%time%"

call :SCRIVI ""
call :SCRIVI "  --------------------------------------------------------------------"
call :SCRIVI "  PARAGRAFO %PAR% - %REL%"
call :SCRIVI "      inizio: %INIZIO%"

if "%STOP%"=="1" (
    call :SCRIVI "      ESITO: SALTATO - blocco per errore precedente"
    >> "%RIEP%" echo(%PAR%  SALTATO  %CARTELLA%
    set /a N_SALT+=1
    exit /b 0
)

if not exist "%FULL%" (
    call :SCRIVI "      ESITO: ERRORE - file non trovato: %FULL%"
    >> "%RIEP%" echo(%PAR%  ERRORE   %CARTELLA%   - file non trovato
    set /a N_ERR+=1
    set "ELENCO_ERR=%ELENCO_ERR% %PAR%"
    if "%FERMA_SU_ERRORE%"=="1" set "STOP=1"
    exit /b 1
)

pushd "%DIR%"
REM  input da NUL: i PAUSE / TIMEOUT del bat figlio non attendono tasti
call "%FULL%" < nul
set "RC=%errorlevel%"
popd
@echo off
cd /d "%BASE%"

call :SCRIVI "      fine  : %time%"
call :SCRIVI "      debug : %DBG%"
if "%RC%"=="0" (
    call :SCRIVI "      ESITO: OK"
    >> "%RIEP%" echo(%PAR%  OK       %CARTELLA%
    set /a N_OK+=1
    call :DEBUG_OK
    exit /b 0
)

call :SCRIVI "      ESITO: ERRORE - codice %RC%"
>> "%RIEP%" echo(%PAR%  ERRORE   %CARTELLA%   - codice %RC%
set /a N_ERR+=1
set "ELENCO_ERR=%ELENCO_ERR% %PAR%"
if "%FERMA_SU_ERRORE%"=="1" set "STOP=1"
call :DEBUG_ERRORE
exit /b %RC%

REM --------------------------------------------------------------------------
REM  :DEBUG_OK  -> copia nel LOG le righe chiave del file di debug
REM                (archivio creato, esito 7-Zip, esito CRIPTA)
REM --------------------------------------------------------------------------
:DEBUG_OK
if not exist "%DBG%" (
    call :SCRIVI "      (file di debug non trovato)"
    exit /b 0
)
>> "%LOG%" echo       --- righe chiave di %DEBUG_LOG% ---
powershell -NoProfile -Command "Select-String -LiteralPath '%DBG%' -SimpleMatch -Pattern '07.01 - OUT_ZIP','07.02 - 7-Zip','ERRORE','08.01 - Zip_N70_CRIPTA','FINE BAT' | ForEach-Object { '      | ' + $_.Line }" >> "%LOG%"
>> "%LOG%" echo       --- fine estratto ---
exit /b 0

REM --------------------------------------------------------------------------
REM  :DEBUG_ERRORE  -> copia nel LOG le ultime 30 righe del file di debug
REM --------------------------------------------------------------------------
:DEBUG_ERRORE
if not exist "%DBG%" (
    call :SCRIVI "      (file di debug non trovato)"
    exit /b 0
)
>> "%LOG%" echo       --- ultime 30 righe di %DBG% ---
powershell -NoProfile -Command "Get-Content -LiteralPath '%DBG%' -Tail 30 | ForEach-Object { '      | ' + $_ }" >> "%LOG%"
>> "%LOG%" echo       --- fine estratto ---
exit /b 0

REM --------------------------------------------------------------------------
REM  :SCRIVI "testo"  -> scrive a video e nel log
REM --------------------------------------------------------------------------
:SCRIVI
if "%~1"=="" goto :SCRIVI_VUOTO
echo(%~1
>> "%LOG%" echo(%~1
exit /b 0
:SCRIVI_VUOTO
echo.
>> "%LOG%" echo.
exit /b 0
