@echo off
setlocal EnableExtensions DisableDelayedExpansion
title ARCHIVIA CARTELLE - zip datati delle cartelle del progetto
REM ==================================================================================================
REM  FILE      : DOS_FOR_N04_21_CICLO_(ArchiviaCartelle_SENZA_PATH)_NellaCartellaCorrente.bat
REM  SCOPO     : per OGNI CARTELLA della cartella corrente (es. MSys_DF00) crea, una sola volta,
REM                AA_SALVATAGGI\MSys_DF00_SALVATAGGI\
REM              e al suo interno aggiunge a ogni esecuzione uno ZIP datato:
REM                AA_SALVATAGGI\MSys_DF00_SALVATAGGI\2026_11_14_MSys_DF00_SALVATAGGI.zip
REM              Nello zip va tutta la cartella TRANNE le sottocartelle AA_BACKUP_GITHUB e
REM              AA_SALVATAGGI (niente salvataggi dentro i salvataggi) e i file di blocco di Access.
REM              Poi zippa i FILE sciolti della cartella corrente (senza sottocartelle) in
REM                AA_SALVATAGGI\<CORRENTE>_FILE_SALVATAGGI\AAAA_MM_GG_<CORRENTE>_FILE_SALVATAGGI.zip
REM              Nessuna replica delle cartelle: solo zip, che si accumulano nel tempo.
REM  STESSO GIORNO: se lo zip del giorno esiste gia', il nuovo prende anche l'ora
REM              (es. 2026_11_14_H21_M55_S03_MSys_DF00_SALVATAGGI.zip): nulla viene sovrascritto.
REM  COMPRESSORE: 7-Zip (C:\Program Files\7-Zip\7z.exe); se manca, tar.exe di Windows.
REM  LOG       : AA_SALVATAGGI\LOG\ARCHIVIA_CARTELLE_AAAA_MM_GG.txt
REM              ogni riga del log e' identica a quella a video:
REM              AAAA-MM-GG HH:MM:SS | Sez/Par: 03.04 | Esito: OK     | testo
REM              l'output del compressore compare a video e nel log, subito dopo la riga #xx.xx#.
REM  USO       : doppio click. Lavora nella cartella in cui si trova il .bat (SENZA percorsi fissi).
REM              /NOPAUSE = non attende il tasto alla fine (esecuzioni automatiche).
REM  AGGIORNATO: 2026-11-14 (versione ZIP; sostituisce la versione con Rar.exe del 2017)
REM --------------------------------------------------------------------------------------------------
REM  INDICE DELLE SEZIONI E DEI PARAGRAFI   (cerca l'etichetta, es. #03.04#)
REM --------------------------------------------------------------------------------------------------
REM  #01#  IMPOSTAZIONI = variabili generali, data, cartelle, esclusioni, compressore
REM        #01.01# = cartella corrente: percorso e nome; parametro /NOPAUSE
REM        #01.02# = data AAAA_MM_GG e ora HHH_MMM_SSS indipendenti dalle impostazioni internazionali
REM        #01.03# = cartella AA_SALVATAGGI, cartella LOG e file di log
REM        #01.04# = esclusioni: cartelle e file da non mettere negli zip
REM        #01.05# = compressore: 7-Zip oppure tar di Windows
REM  #02#  AVVIO = intestazione del log e controlli iniziali
REM        #02.01# = intestazione del log
REM        #02.02# = controllo del compressore
REM  #03#  CICLO_CARTELLE = uno zip datato per ogni cartella
REM        #03.01# = elenco delle sottocartelle, in ordine alfabetico
REM        #03.02# = cartella da saltare (AA_SALVATAGGI) e cartella <NOME>_SALVATAGGI
REM        #03.03# = nome dello zip datato (con l'ora se quello del giorno esiste gia')
REM        #03.04# = compressione della cartella, con le esclusioni
REM        #03.05# = esito, dimensione dello zip e contatori
REM  #04#  FILE_CARTELLA_CORRENTE = uno zip datato con i file sciolti della cartella corrente
REM        #04.01# = cartella <CORRENTE>_FILE_SALVATAGGI e nome dello zip
REM        #04.02# = elenco dei soli file (nessuna sottocartella)
REM        #04.03# = compressione dei file
REM        #04.04# = esito
REM  #05#  RIEPILOGO = totali, esito finale, pulizia, chiusura
REM        #05.01# = totali e codice di uscita (0 = tutto bene, 1 = almeno un errore)
REM  #90#  ROUTINE = sottoprogrammi richiamati con CALL
REM        #90.01# = :LOG          scrive la STESSA riga a video e nel file di log
REM        #90.02# = :ZIP          comprime con 7-Zip o tar e traduce il codice di uscita
REM        #90.03# = :MOSTRA       porta l'output del compressore a video e nel log
REM        #90.04# = :FINE_ERRORE  chiusura in caso di errore bloccante
REM ==================================================================================================


REM ##################################################################################################
REM ## #01# IMPOSTAZIONI = variabili generali, data, cartelle, esclusioni, compressore
REM ##################################################################################################

REM //#01.01# = cartella corrente: percorso e nome (quella in cui si trova il .bat); parametro /NOPAUSE
set "SEZ_s=01.01"
set "BASE_s=%~dp0"
if "%BASE_s:~-1%"=="\" set "BASE_s=%BASE_s:~0,-1%"
for %%I in ("%BASE_s%") do set "CORRENTE_s=%%~nxI"
set "PAUSA_s=SI"
if /i "%~1"=="/NOPAUSE" set "PAUSA_s=NO"

REM //#01.02# = data AAAA_MM_GG (nomi), AAAA-MM-GG (log) e ora HHH_MMM_SSS (secondo zip dello stesso giorno)
set "SEZ_s=01.02"
set "DATA_s="
for /f "usebackq tokens=1-3 delims=|" %%A in (`powershell -NoProfile -Command "Get-Date -Format 'yyyy_MM_dd|yyyy-MM-dd|\HHH_\Mmm_\Sss'"`) do (
    set "DATA_s=%%A"
    set "DATA_LOG_s=%%B"
    set "ORA_FILE_s=%%C"
)
REM     se PowerShell non risponde uso %DATE% e %TIME% nel formato italiano
if not defined DATA_s set "DATA_s=%DATE:~6,4%_%DATE:~3,2%_%DATE:~0,2%"
if not defined DATA_LOG_s set "DATA_LOG_s=%DATE:~6,4%-%DATE:~3,2%-%DATE:~0,2%"
if not defined ORA_FILE_s set "ORA_FILE_s=H%TIME:~0,2%_M%TIME:~3,2%_S%TIME:~6,2%"
set "ORA_FILE_s=%ORA_FILE_s: =0%"

REM //#01.03# = cartella AA_SALVATAGGI, cartella LOG e file di log
set "SEZ_s=01.03"
set "DEST_s=%BASE_s%\AA_SALVATAGGI"
set "LOGDIR_s=%DEST_s%\LOG"
if not exist "%DEST_s%\" mkdir "%DEST_s%"
if not exist "%LOGDIR_s%\" mkdir "%LOGDIR_s%"
set "LOG_s=%LOGDIR_s%\ARCHIVIA_CARTELLE_%DATA_s%.txt"
if exist "%LOGDIR_s%\" goto :SEZ_0104
echo ERRORE #01.03# impossibile creare la cartella del log
set "LOG_s=NUL"
goto :FINE_ERRORE

:SEZ_0104
REM //#01.04# = esclusioni: cartelle e file da non mettere negli zip
set "SEZ_s=01.04"
REM     cartelle escluse a qualsiasi livello (aggiungi altri nomi separati da uno spazio)
set "ESCLUDI_CARTELLE_s=AA_BACKUP_GITHUB AA_SALVATAGGI"
REM     file esclusi: blocchi di Access aperti (aggiungi altri modelli separati da uno spazio)
set "ESCLUDI_FILE_s=*.ldb *.laccdb"
REM     cartella della cartella corrente da NON zippare: e' la destinazione stessa
set "SALTA_s=AA_SALVATAGGI"
REM     opzioni di esclusione gia' pronte per 7-Zip (-xr!nome) e per tar (--exclude=nome)
set "X7_s=-xr!%ESCLUDI_CARTELLE_s: = -xr!% -xr!%ESCLUDI_FILE_s: = -xr!%"
set "XT_s=--exclude=%ESCLUDI_CARTELLE_s: = --exclude=% --exclude=%ESCLUDI_FILE_s: = --exclude=%"
REM     file temporanei di lavoro
set "OUT_s=%TEMP%\ARCHIVIA_CARTELLE_%RANDOM%_output.txt"
set "LISTA_s=%TEMP%\ARCHIVIA_CARTELLE_%RANDOM%_file.txt"
set /a N_TOT=0, N_OK=0, N_AVV=0, N_ERR=0
set "ESITO_FILE_s=non eseguito"

REM //#01.05# = compressore: 7-Zip oppure tar di Windows
set "SEZ_s=01.05"
set "COMPR_s="
set "Z7_s=%ProgramFiles%\7-Zip\7z.exe"
if exist "%Z7_s%" set "COMPR_s=7ZIP"
if not defined COMPR_s if exist "%ProgramFiles(x86)%\7-Zip\7z.exe" set "Z7_s=%ProgramFiles(x86)%\7-Zip\7z.exe"
if not defined COMPR_s if exist "%Z7_s%" set "COMPR_s=7ZIP"
if defined COMPR_s goto :SEZ_02
where tar >nul 2>&1
if not errorlevel 1 set "COMPR_s=TAR"

:SEZ_02


REM ##################################################################################################
REM ## #02# AVVIO = intestazione del log e controlli iniziali
REM ##################################################################################################

REM //#02.01# = intestazione del log
set "SEZ_s=02.01"
call :LOG "------" "=================================================================================="
call :LOG "INIZIO" "ARCHIVIAZIONE ZIP delle cartelle di %CORRENTE_s% - salvataggi del %DATA_s%"
call :LOG "INFO" "cartella corrente : %BASE_s%"
call :LOG "INFO" "destinazione      : %DEST_s%\<CARTELLA>_SALVATAGGI\%DATA_s%_<CARTELLA>_SALVATAGGI.zip"
call :LOG "INFO" "escluse dagli zip : cartelle %ESCLUDI_CARTELLE_s% - file %ESCLUDI_FILE_s%"
call :LOG "INFO" "file di log       : %LOG_s%"

REM //#02.02# = controllo del compressore
set "SEZ_s=02.02"
if not defined COMPR_s goto :NO_COMPRESSORE
if "%COMPR_s%"=="7ZIP" call :LOG "OK" "compressore: 7-Zip - %Z7_s%"
if "%COMPR_s%"=="TAR" call :LOG "AVVISO" "7-Zip non trovato: uso tar.exe di Windows"
goto :SEZ_03
:NO_COMPRESSORE
call :LOG "ERRORE" "nessun compressore disponibile: installa 7-Zip in %ProgramFiles%\7-Zip"
goto :FINE_ERRORE


REM ##################################################################################################
REM ## #03# CICLO_CARTELLE = uno zip datato per ogni cartella
REM ##################################################################################################
:SEZ_03

REM //#03.01# = elenco delle sottocartelle, in ordine alfabetico
set "SEZ_s=03.01"
call :LOG "INIZIO" "ciclo sulle cartelle di %CORRENTE_s%"
for /f "delims=" %%G in ('dir /b /a:d "%BASE_s%" ^| sort') do call :ZIP_CARTELLA "%%G"
set "SEZ_s=03.01"
call :LOG "FINE" "ciclo cartelle concluso: zip creati %N_OK% su %N_TOT%, con avvisi %N_AVV%, errori %N_ERR%"
goto :SEZ_04

:ZIP_CARTELLA
REM //#03.02# = cartella da saltare (AA_SALVATAGGI) e cartella <NOME>_SALVATAGGI
set "SEZ_s=03.02"
set "NOME_s=%~1"
if /i not "%NOME_s%"=="%SALTA_s%" goto :ZC_CARTELLA
call :LOG "INFO" "saltata %NOME_s%: e' la cartella che contiene i salvataggi"
goto :eof
:ZC_CARTELLA
set "CART_s=%DEST_s%\%NOME_s%_SALVATAGGI"
call :LOG "INIZIO" "cartella %NOME_s%"
if exist "%CART_s%\" goto :ZC_NOME
mkdir "%CART_s%"
call :LOG "INFO" "creata la cartella AA_SALVATAGGI\%NOME_s%_SALVATAGGI"

:ZC_NOME
REM //#03.03# = nome dello zip datato (con l'ora se quello del giorno esiste gia')
set "SEZ_s=03.03"
set "ZIP_s=%CART_s%\%DATA_s%_%NOME_s%_SALVATAGGI.zip"
if not exist "%ZIP_s%" goto :ZC_COMPRIMI
set "ZIP_s=%CART_s%\%DATA_s%_%ORA_FILE_s%_%NOME_s%_SALVATAGGI.zip"
call :LOG "AVVISO" "lo zip di oggi esiste gia': creo un nuovo zip con l'ora %ORA_FILE_s%"

:ZC_COMPRIMI
REM //#03.04# = compressione della cartella, con le esclusioni
set "SEZ_s=03.04"
for %%Z in ("%ZIP_s%") do call :LOG "INFO" "creo %NOME_s%_SALVATAGGI\%%~nxZ"
call :ZIP CARTELLA "%NOME_s%" "%ZIP_s%"

REM //#03.05# = esito, dimensione dello zip e contatori
set "SEZ_s=03.05"
set /a N_TOT+=1
if "%ESITO_s%"=="ERRORE" goto :ZC_ERRORE
set /a N_OK+=1
if "%ESITO_s%"=="AVVISO" set /a N_AVV+=1
call :LOG "%ESITO_s%" "%NOME_s%: zip creato, %KB_s% KB - %DESCR_s%"
goto :eof
:ZC_ERRORE
set /a N_ERR+=1
call :LOG "ERRORE" "%NOME_s%: zip NON creato - %DESCR_s% - vedi l'output del compressore qui sopra"
goto :eof


REM ##################################################################################################
REM ## #04# FILE_CARTELLA_CORRENTE = uno zip datato con i file sciolti della cartella corrente
REM ##################################################################################################
:SEZ_04

REM //#04.01# = cartella <CORRENTE>_FILE_SALVATAGGI e nome dello zip
set "SEZ_s=04.01"
set "CART_s=%DEST_s%\%CORRENTE_s%_FILE_SALVATAGGI"
if not exist "%CART_s%\" mkdir "%CART_s%"
set "ZIP_s=%CART_s%\%DATA_s%_%CORRENTE_s%_FILE_SALVATAGGI.zip"
if exist "%ZIP_s%" set "ZIP_s=%CART_s%\%DATA_s%_%ORA_FILE_s%_%CORRENTE_s%_FILE_SALVATAGGI.zip"
for %%Z in ("%ZIP_s%") do call :LOG "INIZIO" "file sciolti di %CORRENTE_s% -> %CORRENTE_s%_FILE_SALVATAGGI\%%~nxZ"

REM //#04.02# = elenco dei soli file (nessuna sottocartella)
set "SEZ_s=04.02"
dir /b /a:-d "%BASE_s%" > "%LISTA_s%" 2>nul
set "N_FILE_i=0"
for /f "usebackq delims=" %%F in ("%LISTA_s%") do set /a N_FILE_i+=1
call :LOG "INFO" "file da salvare: %N_FILE_i%"
if %N_FILE_i% GTR 0 goto :SEZ_0403
set "ESITO_FILE_s=nessun file"
call :LOG "INFO" "nessun file sciolto nella cartella corrente"
goto :SEZ_05

:SEZ_0403
REM //#04.03# = compressione dei file
set "SEZ_s=04.03"
call :ZIP FILE "%LISTA_s%" "%ZIP_s%"

REM //#04.04# = esito
set "SEZ_s=04.04"
if "%ESITO_s%"=="ERRORE" goto :SEZ_04_ERRORE
set "ESITO_FILE_s=zip creato"
if "%ESITO_s%"=="AVVISO" set /a N_AVV+=1
call :LOG "%ESITO_s%" "file sciolti: zip creato, %KB_s% KB - %DESCR_s%"
goto :SEZ_05
:SEZ_04_ERRORE
set /a N_ERR+=1
set "ESITO_FILE_s=ERRORE"
call :LOG "ERRORE" "file sciolti: zip NON creato - %DESCR_s%"


REM ##################################################################################################
REM ## #05# RIEPILOGO = totali, esito finale, pulizia, chiusura
REM ##################################################################################################
:SEZ_05

REM //#05.01# = totali e codice di uscita
set "SEZ_s=05.01"
if exist "%OUT_s%" del "%OUT_s%"
if exist "%LISTA_s%" del "%LISTA_s%"
set "CODICE_i=0"
if %N_ERR% GTR 0 set "CODICE_i=1"
call :LOG "FINE" "RIEPILOGO: zip cartelle %N_OK% su %N_TOT% - file sciolti: %ESITO_FILE_s% - avvisi: %N_AVV% - errori: %N_ERR%"
if %CODICE_i% EQU 0 call :LOG "FINE" "ARCHIVIAZIONE COMPLETATA SENZA ERRORI"
if %CODICE_i% NEQ 0 call :LOG "FINE" "ARCHIVIAZIONE CON ERRORI: cerca ERRORE nel log per sezione e paragrafo"
echo.
if /i "%PAUSA_s%"=="SI" pause
endlocal & exit /b %CODICE_i%


REM ##################################################################################################
REM ## #90# ROUTINE = sottoprogrammi richiamati con CALL
REM ##################################################################################################

:LOG
REM //#90.01# = scrive la STESSA riga a video e nel file di log
REM     uso: call :LOG "ESITO" "testo"   (ESITO: INIZIO, OK, INFO, AVVISO, ERRORE, FINE)
set "ORA_s=%TIME: =0%"
set "ORA_s=%ORA_s:~0,8%"
set "ESITO_LOG_s=%~1      "
set "ESITO_LOG_s=%ESITO_LOG_s:~0,6%"
set "RIGA_s=%DATA_LOG_s% %ORA_s% | Sez/Par: %SEZ_s% | Esito: %ESITO_LOG_s% | %~2"
setlocal EnableDelayedExpansion
echo(!RIGA_s!
>>"!LOG_s!" echo(!RIGA_s!
endlocal
goto :eof

:ZIP
REM //#90.02# = comprime con 7-Zip o tar e traduce il codice di uscita
REM     uso: call :ZIP CARTELLA "nome cartella" "file.zip"   oppure   call :ZIP FILE "lista file" "file.zip"
REM     imposta ESITO_s (OK / AVVISO / ERRORE), DESCR_s e KB_s
set "MODO_s=%~1"
set "RC_i=0"
pushd "%BASE_s%"
if "%COMPR_s%%MODO_s%"=="7ZIPCARTELLA" "%Z7_s%" a -tzip -mx=5 -ssw -bsp0 -bb0 "%~3" "%~2" %X7_s% > "%OUT_s%" 2>&1
if "%COMPR_s%%MODO_s%"=="7ZIPFILE"     "%Z7_s%" a -tzip -mx=5 -ssw -bsp0 -bb0 -scsDOS "%~3" @"%~2" %X7_s% > "%OUT_s%" 2>&1
if "%COMPR_s%%MODO_s%"=="TARCARTELLA"  tar -a -c -f "%~3" %XT_s% "%~2" > "%OUT_s%" 2>&1
if "%COMPR_s%%MODO_s%"=="TARFILE"      tar -a -c -f "%~3" %XT_s% -T "%~2" > "%OUT_s%" 2>&1
set "RC_i=%ERRORLEVEL%"
popd
call :MOSTRA
set "KB_s=0"
if exist "%~3" for %%Z in ("%~3") do set /a KB_s=^(%%~zZ+1023^)/1024
set "ESITO_s=OK"
set "DESCR_s=compressione riuscita"
if "%COMPR_s%"=="TAR" goto :ZIP_TAR
if %RC_i% EQU 1 set "ESITO_s=AVVISO"
if %RC_i% EQU 1 set "DESCR_s=alcuni file non sono stati letti, per esempio perche' aperti - vedi output"
if %RC_i% GEQ 2 set "ESITO_s=ERRORE"
if %RC_i% EQU 2 set "DESCR_s=errore grave di 7-Zip, codice 2"
if %RC_i% EQU 7 set "DESCR_s=errore nella riga di comando di 7-Zip, codice 7"
if %RC_i% EQU 8 set "DESCR_s=memoria insufficiente, codice 8"
goto :ZIP_FINE
:ZIP_TAR
if %RC_i% NEQ 0 set "ESITO_s=ERRORE"
if %RC_i% NEQ 0 set "DESCR_s=errore di tar, codice %RC_i%"
:ZIP_FINE
if not exist "%~3" set "ESITO_s=ERRORE"
if not exist "%~3" set "DESCR_s=%DESCR_s% - il file zip non esiste"
goto :eof

:MOSTRA
REM //#90.03# = porta l'output del compressore a video e nel log (righe non vuote)
if not exist "%OUT_s%" goto :eof
for /f "usebackq delims=" %%R in ("%OUT_s%") do (
    echo(       %%R
    >>"%LOG_s%" echo(       %%R
)
goto :eof

:FINE_ERRORE
REM //#90.04# = chiusura in caso di errore bloccante
call :LOG "ERRORE" "procedura interrotta al paragrafo #%SEZ_s%#"
if exist "%OUT_s%" del "%OUT_s%"
if exist "%LISTA_s%" del "%LISTA_s%"
echo.
if /i "%PAUSA_s%"=="SI" pause
endlocal & exit /b 1
